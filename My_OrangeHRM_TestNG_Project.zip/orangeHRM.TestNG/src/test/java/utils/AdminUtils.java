package utils;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import orangeHRM.library.LoginPage;

public class AdminUtils extends Apputils
{

	LoginPage lp;
	@BeforeTest
	public void AdminLogin() {
		lp=new LoginPage();
		lp.AdminLogin("Admin", "Qedge123!@#");
	}
	
	@AfterTest
	public void adminLogout() {
		lp.Logout();
	}
}
