package orangeHRM.library;

import org.openqa.selenium.By;

import utils.Apputils;

public class LoginPage extends Apputils
{

	public void AdminLogin(String uid,String pwd) {
		driver.findElement(By.id("txtUsername")).sendKeys(uid);
		driver.findElement(By.id("txtPassword")).sendKeys(pwd);
		driver.findElement(By.id("btnLogin")).click();
	}
	
	public boolean isAdminModuleDisplayed() {
		if(driver.findElement(By.linkText("Admin")).isDisplayed()) {
			return true;
		}else {
			return false;
		}
	}
	
	public void Logout() {
		driver.findElement(By.partialLinkText("Welcome")).click();
		driver.findElement(By.linkText("Logout")).click();
	}
	
	public boolean isErrMsgDisplayed() {
		String msg=driver.findElement(By.id("spanMessage")).getText().toLowerCase();
		if(msg.contains("invalid") || msg.contains("empty")) {
			return true;
		}else {
			return false;
		}
		
		
	}
	
}
