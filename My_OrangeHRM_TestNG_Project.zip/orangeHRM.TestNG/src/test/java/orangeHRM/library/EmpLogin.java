package orangeHRM.library;

import org.openqa.selenium.By;

import utils.AdminUtils;

public class EmpLogin extends AdminUtils
{

	public void Employee(String Eid,String Epwd) {
		driver.findElement(By.id("txtUsername")).sendKeys(Eid);
		driver.findElement(By.id("txtPassword")).sendKeys(Epwd);
		driver.findElement(By.id("btnLogin")).click();
	}
	
	public boolean isEmpNameDisplayed(String Ename) {
		if(driver.findElement(By.partialLinkText(Ename)).isDisplayed())
		{
			return true;
		}else {
			return false;
		}
	}
}
