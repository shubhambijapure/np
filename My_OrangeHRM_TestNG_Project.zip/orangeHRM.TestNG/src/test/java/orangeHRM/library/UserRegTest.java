package orangeHRM.library;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import utils.AdminUtils;

public class UserRegTest extends AdminUtils
{

	public void AddUser(String empname,String username,String pwd,String cpwd) 
	{
		driver.findElement(By.linkText("Admin")).click();
		driver.findElement(By.id("btnAdd")).click();
		driver.findElement(By.id("systemUser_employeeName_empName")).sendKeys(empname);
		driver.findElement(By.id("systemUser_userName")).sendKeys(username);
		driver.findElement(By.id("systemUser_password")).sendKeys(pwd);
		driver.findElement(By.id("systemUser_confirmPassword")).sendKeys(cpwd);
		driver.findElement(By.name("btnSave")).click();
		
		
	}
	
}
