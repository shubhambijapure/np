package orangeHRM.testcases;

import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import orangeHRM.library.UserRegTest;
import utils.AdminUtils;

public class userRegTestCase extends AdminUtils
{
	
	@Parameters({"empname","username","pwd","cpwd"})
    @Test
	public void UserReg(String empname,String username,String pwd,String cpwd) {
    	UserRegTest user;
    	user=new UserRegTest();
    	user.AddUser(empname,username, pwd, cpwd);
    }
}	

