package orangeHRM.testcases;

import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import orangeHRM.library.EmpRegTest;
import utils.AdminUtils;


public class EmpRegTestcase extends AdminUtils
{
	@Parameters({"fname","lname"})
	@Test
  public void checkEmpReg(String fname,String lname) {
	  EmpRegTest emp=new EmpRegTest();
	  boolean res=emp.AddEmployee(fname, lname);
	  Assert.assertTrue(res);
  }
	
}
