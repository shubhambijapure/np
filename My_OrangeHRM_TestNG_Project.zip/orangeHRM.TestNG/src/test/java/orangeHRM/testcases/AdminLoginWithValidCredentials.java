package orangeHRM.testcases;

import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import orangeHRM.library.LoginPage;
import utils.Apputils;

public class AdminLoginWithValidCredentials extends Apputils
{
    
	@Parameters({"AdminUid","Adminpwd"})
	@Test
	public void checkAdminLogin(String uid,String pwd) {
		LoginPage lp=new LoginPage();
		lp.AdminLogin(uid, pwd);
		boolean res=lp.isAdminModuleDisplayed();
		Assert.assertTrue(res);
		lp.Logout();
	}
}
