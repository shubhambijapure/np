package orangeHRM.testcases;

import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import orangeHRM.library.EmpLogin;
import utils.AdminUtils;

public class EmpLoginTest 
{
	@Parameters({"Eid","Epwd"})
    @Test
	public void EmployeeLogin(String Eid,String Epwd)
	{
	   EmpLogin El=new EmpLogin();
	   El.Employee(Eid, Epwd);
	   boolean res=El.isEmpNameDisplayed("Shubham");
	   Assert.assertTrue(res);
	}
}
