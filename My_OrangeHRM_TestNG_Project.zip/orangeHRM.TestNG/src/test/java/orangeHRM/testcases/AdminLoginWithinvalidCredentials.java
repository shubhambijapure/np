package orangeHRM.testcases;

import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import orangeHRM.library.LoginPage;
import utils.Apputils;

public class AdminLoginWithinvalidCredentials extends Apputils
{
	@Parameters({"uid","pwd"})
	@Test
    public void checkAdminLogin(String uid,String pwd) {
    	LoginPage lp=new LoginPage();
    	lp.AdminLogin(uid, pwd);
    	boolean res=lp.isErrMsgDisplayed();
    	Assert.assertTrue(res);
    }
}
